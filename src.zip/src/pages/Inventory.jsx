import React from "react";
const Inventory = () => {
  return <h2>📦 Đây là trang Hoạt động kho</h2>;
};
export default Inventory;
