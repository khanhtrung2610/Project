import React from "react";
const Categories = () => {
  return <h2>Trang Danh mục thiết bị</h2>;
};
export default Categories;
