import React from "react";
const Payments = () => {
  return <h2>Trang Thanh toán</h2>;
};
export default Payments;
